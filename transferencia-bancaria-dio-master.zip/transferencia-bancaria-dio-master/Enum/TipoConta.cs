namespace transferencia_bancaria_dio
{
    public class TipoConta
    {
        PessoaFisica = 1;
        PessoaJuridica = 2;
    }
}